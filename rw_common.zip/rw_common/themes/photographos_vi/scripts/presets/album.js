//no-conflict
var jQ = jQuery.noConflict();

//main menu
function navMenu() {
    jQ('#navContainer ul ul').hide();
        jQ('#navContainer ul:first').show();
        jQ('#navContainer ul a').click(function() {
            var checkElement = jQ(this).next();
            if((checkElement.is('ul')) && (checkElement.is(':visible'))) {
            return false;
            }
            if((checkElement.is('ul ul')) && (!checkElement.is(':visible'))) {
            jQ('#navContainer ul ul:visible').slideUp('normal');
            checkElement.slideToggle('normal');
            return false;
            }
        }
    );
}

//mobile navigation
function navMenu2() {
    jQ("#navContainer2>ul>li>ul").hide();
    jQ("#navContainer2 li:has(ul)").click(function () {
        jQ(this).children("a").click(function () {
            return !1
        })
    });
    jQ("#navContainer2 li").hover(function () {
        jQ(this).find("ul:first").css("display", "none").slideDown(300)
    }, function () {
        jQ(this).find("ul:first").slideUp(800)
    })
}

jQ(document).ready(function () {   
    //extra-content
    var i=0; while (i<=4){jQ('#myExtraContent'+i+' script').remove();jQ('#myExtraContent'+i).appendTo('#extraContainer'+i); i++; }; 
    
    //start menus   
    navMenu();navMenu2();
    
    //mobile button trigger
    jQ("#navSlide").toggle(function () {
        jQ('.galleria-info').hide();
        jQ("#mobileContainer").slideDown()
    }, function () {
        jQ('.galleria-info').show();
        jQ("#mobileContainer").slideUp()
    });   
       
    //button fades
    jQ('.button-slide').fadeTo('fast', 0.8);
    jQ('.button-slide').hover(function () {jQ(this).fadeTo('fast', 1);},
    function () {jQ(this).fadeTo('fast', 0.8);});
    
    //image fades
    jQ(".image-fade").fadeTo("slow",0.5);
    jQ(".image-fade").hover(function(){ 
       jQ(this).fadeTo("fast",1)},
       function(){jQ(this).fadeTo("fast",0.5)});
    
    //album captions
    jQ(".thumbnail-frame").each(function () {
        var e = jQ("p.thumbnail-caption", this).text();
        jQ("img", this).attr("alt", e)
    });
    
    //slideshow trigger  
    jQ(".album-wrapper a").each(function () {
        jQ(this).attr("href", jQ(this).attr("href").replace(".html", ".jpg"))
    });
    
    //content slide
    wrapperHeight = jQ(window).height();
    jQ("#extraWrapper").animate({top: wrapperHeight}, 800);
    jQ(".contentDown").click(function () {
        jQ(".galleria-container, #navWrapper, #contentContainer").animate({top: wrapperHeight}, 800).fadeOut();
        jQ("#navSlide").fadeOut();
        jQ("#extraWrapper").fadeIn().css("visibility", "visible").animate({top: '0'}, 800);
    }); 
    jQ(".contentUp").click(function () {
        jQ(".galleria-container, #navWrapper, #contentContainer, #navSlide").fadeIn().animate({top: '0'}, 800);
        jQ("#navSlide").fadeIn();
        jQ("#extraWrapper").animate({top: wrapperHeight}, 800).fadeOut();
    });
    
    //page specific
    jQ('#sidebarContainer').css({'position': 'absolute', 'width': '92%', 'padding': 20})
    
    //start layout
    Galleria.loadTheme(gPath);    
    Galleria.run('#content'); 
    jQ('#contentContainer, #navWrapper').fadeIn(500); 
});