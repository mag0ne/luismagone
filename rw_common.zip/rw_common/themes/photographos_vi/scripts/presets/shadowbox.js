var jQ = jQuery.noConflict();

//main menu
function navMenu() {
    jQ('#navContainer ul ul').hide();
        jQ('#navContainer ul:first').show();
        jQ('#navContainer ul a').click(function() {
            var checkElement = jQ(this).next();
            if((checkElement.is('ul')) && (checkElement.is(':visible'))) {
            return false;
            }
            if((checkElement.is('ul ul')) && (!checkElement.is(':visible'))) {
            jQ('#navContainer ul ul:visible').slideUp('normal');
            checkElement.slideToggle('normal');
            return false;
            }
        }
    );
}

//mobile navigation
function navMenu2() {
    jQ("#navContainer2>ul>li>ul").hide();
    jQ("#navContainer2 li:has(ul)").click(function () {
        jQ(this).children("a").click(function () {
            return !1
        })
    });
    jQ("#navContainer2 li").hover(function () {
        jQ(this).find("ul:first").css("display", "none").slideDown(300)
    }, function () {
        jQ(this).find("ul:first").slideUp(800)
    })
}

//shadowbox setup
function setUpPhotoAlbumSB() {
	var contentDivs = new Array();
	var contentDiv=document.getElementById("content");
	contentDivs = contentDiv.getElementsByTagName('div');
	for (i=0; i<contentDivs.length; i++) {
		if (contentDivs[i].className=='thumbnail-frame') {
			var theLink=contentDivs[i].getElementsByTagName('a');
			
			for (j=0; j<theLink.length; j++){
				var theDescription=theLink[j].parentNode.getElementsByTagName('p')[0].innerHTML;
				var htmlURL=theLink[j].getAttribute('href');
				var imageURL=htmlURL.replace(/html/, 'jpg');
				theLink[j].setAttribute('href', imageURL);
				theLink[j].setAttribute('rel', 'shadowbox[photoSet]');
				theLink[j].setAttribute('title', theDescription);
			}
	    }
	}
}

//shadowbox trigger	    	
function setUpSB(){
	Shadowbox.setup(".thumbnail-frame a", {
		gallery:"My Movies"
	});
}

//document ready
jQ(document).ready(function () { 
    //extra-content
    var i=0; while (i<=3){jQ('#myExtraContent'+i+' script').remove();jQ('#myExtraContent'+i).appendTo('#extraContainer'+i); i++; };
    
    //start menus   
    navMenu();navMenu2();
    
    //mobile button trigger
    jQ("#navSlide").toggle(function () {
        jQ('.galleria-info').hide();
        jQ("#mobileContainer").slideDown()
    }, function () {
        jQ('.galleria-info').show();
        jQ("#mobileContainer").slideUp()
    });

    //shadowbox call
    jQ.getScript(sPath, function(){
    jQ(function () {
        setUpPhotoAlbumSB();
        setUpSB();
        Shadowbox.init();
    });     
       
    //button fades
    jQ('.button-slide').fadeTo('fast', 0.5);
    jQ('.button-slide').hover(function () {
        jQ(this).fadeTo('fast', 1);
        },
        function () {
            jQ(this).fadeTo('fast', 0.5);
        }
    );
    
    //image fades
    jQ(".image-fade").fadeTo("slow",0.5);
    jQ(".image-fade").hover(function(){ 
       jQ(this).fadeTo("fast",1)},
       function(){jQ(this).fadeTo("fast",0.5)});
    
    //ec1 and button
    wrapperWidth = jQ('#navWrapper').width();
    wrapperHeight = jQ('#navWrapper').height();
    jQ("#extraWrapper").animate({top: wrapperHeight}, 800);

    //content slide
    jQ(".contentDown").click(function () {
        jQ(".galleria-container, #navWrapper, #contentContainer").animate({top: wrapperHeight}, 800).fadeOut();
        jQ("#navSlide").fadeOut();
        jQ("#extraWrapper").fadeIn().css("visibility", "visible").animate({top: '0'}, 800);
    }); 
             
    jQ(".contentUp").click(function () {
        jQ(".galleria-container, #navWrapper, #contentContainer, #navSlide").fadeIn().animate({top: '0'}, 800);
        jQ("#navSlide").fadeIn();
        jQ("#extraWrapper").animate({top: wrapperHeight}, 800).fadeOut();
    });
    
    //page specific
    jQ('#content').css('max-width', 1000);
    jQ('#navWrapper').css('height', '100%');
    
    //start layout 
    jQ('#contentContainer, #navWrapper').fadeIn(500); 
    }, true);
});